// console.log(document.querySelectorAll('p'));

// console.log(document.querySelector('.name'));

// console.log(document.querySelector('#image'));


// document.querySelector('#para2').innerHTML

function changeImage()
{
   document.querySelector('#image').src="https://www.looper.com/img/gallery/the-untold-truth-of-marvels-loki/intro-1622826186.jpg";
}

function getValue()
{
    console.log(document.querySelector("#inp").value);
}

function changeStyle()
{
    document.querySelector('#one').style.backgroundColor="blue";

    

}




